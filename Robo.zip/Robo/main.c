/*
 * main.c
 *
 *  Created on: 2016 Oct 19 13:11:23
 *  Author: wam47409
 */




#include <DAVE.h>                 //Declarations from DAVE Code Generation (includes SFR declaration)

/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 */
int Measure (void);
int UART_Send (void);

uint8_t ReadData = 0;
uint8_t SendData[8];


int main(void)
{


  DAVE_STATUS_t status;

  status = DAVE_Init();           /* Initialization of DAVE APPs  */

  if(status != DAVE_STATUS_SUCCESS)
  {
    /* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
    XMC_DEBUG("DAVE APPs initialization failed\n");

    while(1U)
    {



    }
  }

  /* Placeholder for user application code. The while loop below can be replaced with user application code. */
  while(1U)
  {
	  if(UART_Receive(&UART_0, ReadData, 1) == UART_STATUS_SUCCESS)
	  {
		  if(ReadData > 0)
		  {

			  TIMER_Start(&TIMER_0);


			  if(ReadData > 195)
			  {
				  DIGITAL_IO_SetOutputHigh(&DIGITAL_IO_0);
			  }
			  else
			  {
				  DIGITAL_IO_SetOutputLow(&DIGITAL_IO_0);
			  }
		  }

		  else
		  {
			  TIMER_Stop(&TIMER_0);
		  }
	  }
  }
}


int Measure (void)
{
	ADC_MEASUREMENT_StartConversion(&ADC_MEASUREMENT_0);
}

int UART_Send (void)
{
	SendData[0] = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Red_L);
	SendData[1] = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Green_L);
	SendData[2] = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Blue_L);
	SendData[3] = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Red_R);
	SendData[4] = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Green_R);
	SendData[5] = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Blue_R);
	SendData[6] = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Infra);
	SendData[7] = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Ultra);


	UART_Transmit(&UART_0, SendData, 8);


}

