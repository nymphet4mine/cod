/*
 * main.c
 *
 *  Created on: 2016 Dec 30 14:17:08
 *  Author: Dominik
 */



#include <DAVE.h>                 //Declarations from DAVE Code Generation (includes SFR declaration)
#include "TCS34725.h"

#define MSEC 1000
#define commonAnode true
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define MIN(a, b) (((a) < (b)) ? (a) : (b))

uint32_t TimerId = 0;
uint32_t Tstatus;
bool end_timer = true;
uint8_t transmit;
bool restart = false;
bool pinWhite_high = false;
bool pinRed_high = false;
bool pinBlue_high = false;
uint8_t failCount = 0;
uint8_t noFailCount=0;

void Color_ConversionHSL(float red1, float green1, float blue1)
{
	float hue, saturation, fmax, fmin;
	fmax=MAX(MAX(red1, green1), blue1);
	fmin = MIN(MIN(red1, green1), blue1);


	if(fmax > 0)
		saturation = (fmax-fmin) / fmax;
	else
		saturation = 0;

	if(saturation == 0)
		hue = 0;
	else
	{
		if(fmax==red1)
			hue = (green1 - blue1) / (fmax - fmin);
		else if(fmax == green1)
			hue = 2 + (blue1 - red1) / (fmax-fmin);
		else
			hue = 4 + (red1 - green1) / (fmax-fmin);
		hue = hue / 6;
		if (hue<0) hue += 1;
	}
}

void delay()
{
	end_timer=false;
}
void startTimer(uint16_t msec)
{
	if(TimerId == 0)
		{
			TimerId = SYSTIMER_CreateTimer(msec*MSEC,SYSTIMER_MODE_ONE_SHOT,(void*)delay,NULL);
			Tstatus=SYSTIMER_StartTimer(TimerId);
		}
	else
		{
		Tstatus = SYSTIMER_RestartTimer(TimerId,msec*MSEC);
		}

	if (Tstatus == SYSTIMER_STATUS_SUCCESS)
	    {

			while(end_timer);
			end_timer=true;
	    }
	Tstatus = SYSTIMER_StopTimer(TimerId);
}

void Transmit(uint8_t pos, uint8_t bytes, bool start, bool stop)
{
	uint16_t count=0;
	I2C_MASTER_Transmit(&I2C_Sensor,start,TCS34725_ADDRESS,&transmit,1,stop);
	while(I2C_MASTER_IsTxBusy(&I2C_Sensor))
	{
		count++;
		if(count>=5000){ restart=true; return;}
	}
}
uint8_t Receive(bool start, bool stop)
{
	uint16_t count=0;
	uint8_t rec;

	I2C_MASTER_Receive(&I2C_Sensor,start,TCS34725_ADDRESS,&rec,1,stop,true);
	while(I2C_MASTER_IsRxBusy(&I2C_Sensor))
	{
		count++;
		if(count>=5000){ restart=true; return 0;}
	}

	return rec;
}

void Adafruit_TCS34725(tcs34725IntegrationTime_t it, tcs34725Gain_t gain)
  {
    _tcs34725Initialised = false;
    _tcs34725IntegrationTime = it;
    _tcs34725Gain = gain;
  }
bool begin()
  {
	  uint8_t x = read8(TCS34725_ID);
	  if(restart) return false;
	  if ((x != 0x44))
	  {
	    while(1);
	    return false;
	  }

	  _tcs34725Initialised = true;

	  setIntegrationTime(_tcs34725IntegrationTime);
	  if(restart) return false;
	  setGain(_tcs34725Gain);
	  if(restart) return false;

	  enable();

	  return true;

  }
void enable(void)
{
  write8(TCS34725_ENABLE, TCS34725_ENABLE_PON);
  if(restart) return;
  startTimer(3);
  write8(TCS34725_ENABLE, TCS34725_ENABLE_PON | TCS34725_ENABLE_AEN);
}
void disable(void)
{
  uint8_t reg = 0;
  reg = read8(TCS34725_ENABLE);
  write8(TCS34725_ENABLE, reg & ~(TCS34725_ENABLE_PON | TCS34725_ENABLE_AEN));
}

uint8_t read8(uint8_t reg)
{
	transmit = reg | TCS34725_COMMAND_BIT;
	Transmit(0, 1, true, false);
	if(restart) return 0;

	return Receive(true, true);
}
uint16_t read16(uint8_t reg)
{
  uint16_t x; uint16_t t;

	transmit = reg | TCS34725_COMMAND_BIT;
	Transmit(0, 1, true, false);
	if(restart) return 0;


  t = Receive(true, false);
  if(restart) return 0;
  x = Receive(true, true);
  if(restart) return 0;

  x <<= 8;
  x |= t;
  return x;
}

void write8 (uint8_t reg, uint32_t value)
{
	transmit = reg | TCS34725_COMMAND_BIT;
	Transmit(0, 1, true, false);
	if(restart)return;

	transmit = value & 0xFF;
	Transmit(1, 1, true, true);
	if(restart)return;
}

void setIntegrationTime(tcs34725IntegrationTime_t it)
{
  if (!_tcs34725Initialised) begin();

  write8(TCS34725_ATIME, it);

  _tcs34725IntegrationTime = it;
}
void setGain(tcs34725Gain_t gain)
{
  if (!_tcs34725Initialised) begin();

  write8(TCS34725_CONTROL, gain);

  _tcs34725Gain = gain;
}
void setInterrupt(bool i)
{
  uint8_t r = read8(TCS34725_ENABLE);
  if(restart) return;
  if (i) {
    r |= TCS34725_ENABLE_AIEN;
  } else {
    r &= ~TCS34725_ENABLE_AIEN;
  }
  write8(TCS34725_ENABLE, r);
}

void getRawData (uint16_t *r, uint16_t *g, uint16_t *b, uint16_t *c)
{
  if (!_tcs34725Initialised) begin();

  *c = read16(TCS34725_CDATAL);
  if(restart) return;
  *r = read16(TCS34725_RDATAL);
  if(restart) return;
  *g = read16(TCS34725_GDATAL);
  if(restart) return;
  *b = read16(TCS34725_BDATAL);
  if(restart) return;

  switch (_tcs34725IntegrationTime)
  {
    case TCS34725_INTEGRATIONTIME_2_4MS:
    	startTimer(3);
      break;
    case TCS34725_INTEGRATIONTIME_24MS:
    	startTimer(24);
      break;
    case TCS34725_INTEGRATIONTIME_50MS:
    	startTimer(50);
      break;
    case TCS34725_INTEGRATIONTIME_101MS:
    	startTimer(101);
      break;
    case TCS34725_INTEGRATIONTIME_154MS:
    	startTimer(154);
      break;
    case TCS34725_INTEGRATIONTIME_700MS:
    	startTimer(700);
      break;
  }
}

void startMeasure()
{
	  Adafruit_TCS34725(TCS34725_INTEGRATIONTIME_2_4MS, TCS34725_GAIN_4X);
	  begin();
	  uint16_t count=0;
	  uint16_t fehlerCount=0;
	  /* Placeholder for user application code. The while loop below can be replaced with user application code. */
	  while(1U)
	  {
		  uint16_t red=0,  green=0,  blue=0, clear=0;
		  getRawData (&red, &green, &blue, &clear);
		  if(restart) return;
		  while(red == 0 || green==0 || blue == 0)
		  	  {
		  		  fehlerCount++;
		  		  getRawData (&red, &green, &blue, &clear);
		  		  if(restart) return;
		  	  }

		  if(red==green && red == blue)
		  {
			  if(!pinWhite_high)
			  {
				  DIGITAL_IO_SetOutputHigh(&Weiss1);
				  pinWhite_high = true;
			  }
		  }
		  else
			  if(pinWhite_high)
			  {
				  DIGITAL_IO_SetOutputLow(&Weiss1);
				  pinWhite_high=false;
			  }

		  if(red > 65500 && blue < 62000 && green < 62000)
		  {
			  if(!pinRed_high)
			  {
				  DIGITAL_IO_SetOutputHigh(&Rot);
				  pinRed_high = true;
			  }
		  }
		  else
			  if(pinRed_high)
				  {
				  DIGITAL_IO_SetOutputLow(&Rot);
				  pinRed_high = false;
				  }

		  if(blue > 65500 && red < 62000 && green < 62000)
		  {
			  if(!pinBlue_high)
			  {
				  DIGITAL_IO_SetOutputHigh(&Blau);
				  pinBlue_high = true;
			  }
		  }
		  else
			  if(pinBlue_high)
			  {
				  DIGITAL_IO_SetOutputLow(&Blau);
				  pinBlue_high = false;
			  }

		  count++;
		  noFailCount++;
	  }
}

int main(void)
{
  DAVE_STATUS_t status;

  status = DAVE_Init();           /* Initialization of DAVE APPs  */

  if(status != DAVE_STATUS_SUCCESS)
  {
    /* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
    XMC_DEBUG("DAVE APPs initialization failed\n");

    while(1U)
    {

    }
  }


  /* Placeholder for user application code. The while loop below can be replaced with user application code. */
  while(1U)
  {
	  startTimer(300);
	  startMeasure();
	  _tcs34725Initialised=false;
	  restart=false;
	  if(pinWhite_high) DIGITAL_IO_SetOutputLow(&Weiss1);
	  if(pinRed_high) DIGITAL_IO_SetOutputLow(&Rot);
	  if(pinBlue_high) DIGITAL_IO_SetOutputLow(&Blau);
	  pinWhite_high = false;
	  pinRed_high = false;
	  pinBlue_high = false;
	  failCount++;
  }
}
